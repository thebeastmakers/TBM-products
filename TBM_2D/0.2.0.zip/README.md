# TBM_2D
Convert maya animated curves to 2D layered texture files with opengl display


## Changelog
- #### 0.2 : 
  - Level Of Detail : Add possibility to dynamically change the texture size when running the *TBM_2DRecord* command. The size is processed according to the distance between a camera and an object provided to the node.
  - Fix thickness behavior : Switching the thickness now works also for the thickness value/ramp and not only on the factor.
  - Any error on record now stops the record.
  - Fix crash occuring when rendering using *Maya Software*
  - Fix thickness behavior : The ramp is now correctly processed when adaptative sampling is used.
  - The image rendered with the command *TBM_2DRecord* are now named with the frame number instead of an internal counter. It allows the user to use the flags *-fs* and *-fe* to regenerate easily a portion of the animation.
  - Fix UV processing to correctly show the texture when rendering using *Maya Software*

  > Known issue : To render using *Maya Software*, it may be necesssary to call at least once the compute of the node , for that just move the time in the animation timeline before starting the rendering (bug still on investigation).
